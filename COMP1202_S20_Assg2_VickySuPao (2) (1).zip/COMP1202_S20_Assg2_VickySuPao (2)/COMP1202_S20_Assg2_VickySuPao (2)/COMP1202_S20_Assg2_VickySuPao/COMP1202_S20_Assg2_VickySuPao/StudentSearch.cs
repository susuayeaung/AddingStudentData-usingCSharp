﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using static System.Console;
using System.Threading.Tasks;

namespace COMP1202_S20_Assg2_VickySuPao
{
    class StudentSearch
    {
        public static Student GetStudentsSearch(Student[] students)
        {
            int searchTypeNumber;
            int index = -1;
            Student studentInfo;

            WriteLine("Please enter the number you want to search for？\n 1.StudentID \n 2.Major \n 3. Higher GPA \n 4. Lower GPA \n 5. All  data ");
            searchTypeNumber = Convert.ToInt32(ReadLine());

            if (searchTypeNumber == 1)
            {
                WriteLine("Please enter Student ID you want to search for: ");
                String searchId = ReadLine();
                bool found = false;
                for (int j = 0; j < students.Length && !found; j++)
                {
                    if (students[j].Id.Equals(searchId))
                    {
                        found = true;
                        index = j;
                    }
                }

                if (found == true)
                {
                    studentInfo = students[index];

                }

                return students[index];
            }
            else if (searchTypeNumber == 2)
            {
                WriteLine("Please enter major you want to search for: ");
                String searchMajor = ReadLine();
                bool found = false;
                for (int j = 0; j < students.Length; j++)
                {
                    if (students[j].Major.Equals(searchMajor))
                    {
                        found = true;
                        index = j;
                    }
                }

                if (found == true)
                {
                    studentInfo = students[index];
                    
                }

                return students[index];
            }
            else if (searchTypeNumber == 3)
            {
                WriteLine("Please enter GPA you want to search for: ");
                String searchGpa = ReadLine();
                bool found = false;
                for (int j = 0; j < students.Length; j++)
                {
                    if (students[j].Gpa.Equals(searchGpa))
                    {
                        found = true;
                        index = j;
                    }
                }

                if (found == true)
                {
                    studentInfo = students[index];
                    
                }

                return students[index];
            }
            else
            {
                WriteLine("You have entered an invalid option");
                return null;
                
            }            
        }
    }
}
